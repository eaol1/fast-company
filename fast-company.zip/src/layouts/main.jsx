import React from "react"

const Main = () => {
  return (
    <div className="container">
      <h1>Main Page</h1>
    </div>
  )
}
export default Main
