module.exports = {
  trailingComma: "none",
  singleQuote: false,
  jsxSingleQuote: false,
  tabWidth: 2,
  semi: false
}
